<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body" id="page_dashboard">
	<header class="page-header">
		<h2>Dashboard</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Dashboard</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<div class="row">
		<div class="col-md-6 col-lg-12">
			<div class="row">
				<div class="col-md-12 col-lg-4">
					<section class="panel">
						<div class="panel-body bg-primary">
							<div class="widget-summary">
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Pendapatan Hari Ini</h4>
										<div class="info">
											<strong class="amount"><?= 'Rp ' . $todayIncome; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<div class="col-md-12 col-lg-4">
					<section class="panel">
						<div class="panel-body bg-tertiary">
							<div class="widget-summary">
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Pendapatan Bulan Ini</h4>
										<div class="info">
											<strong class="amount"><?= 'Rp ' . $monthIncome; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<div class="col-md-12 col-lg-4">
					<section class="panel">
						<div class="panel-body bg-secondary">
							<div class="widget-summary">
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Keuntungan Bulan Ini</h4>
										<div class="info">
											<strong class="amount"><?= 'Rp ' . $totalUser; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-lg-12">
			<div class="row">
				<div class="col-md-12 col-lg-4">
					<section class="panel panel-featured-left panel-featured-primary">
						<div class="panel-body">
							<div class="widget-summary widget-summary-md">
								<div class="widget-summary-col widget-summary-col-icon">
									<div class="summary-icon bg-primary">
										<i class="fa fa-sign-out"></i>
									</div>
								</div>
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Barang Keluar Hari Ini</h4>
										<div class="info">
											<strong class="amount"><?= $totalItem; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<div class="col-md-12 col-lg-4">
					<section class="panel panel-featured-left panel-featured-secondary">
						<div class="panel-body">
							<div class="widget-summary widget-summary-md">
								<div class="widget-summary-col widget-summary-col-icon">
									<div class="summary-icon bg-secondary">
										<i class="fa fa-sign-in"></i>
									</div>
								</div>
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Barang Masuk Hari Ini</h4>
										<div class="info">
											<strong class="amount"><?= $totalSupplier; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<div class="col-md-12 col-lg-4">
					<section class="panel panel-featured-left panel-featured-tertiary">
						<div class="panel-body">
							<div class="widget-summary widget-summary-md">
								<div class="widget-summary-col widget-summary-col-icon">
									<div class="summary-icon bg-tertiary">
										<i class="fa fa-times"></i>
									</div>
								</div>
								<div class="widget-summary-col">
									<div class="summary">
										<h4 class="title">Stok Barang Kurang Dari 10!</h4>
										<div class="info">
											<strong class="amount"><?= $totalUser; ?></strong>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-lg-12 col-xl-6">
			<section class="panel">
				<div class="panel-body">
					<div class="row">
						<div class="col-lg-12">
							<div class="chart-data-selector" id="salesSelectorWrapper">
								<h2>
									Grafik:
									<strong>
										<select class="form-control" id="salesSelector">
											<option value="Porto Admin" selected>Penjualan</option>
											<option value="Porto Drupal">Barang Terbaik</option>
										</select>
									</strong>
								</h2>

								<div id="salesSelectorItems" class="chart-data-selector-items mt-sm">
									<!-- Flot: Sales -->
									<div class="chart chart-sm" data-sales-rel="Porto Admin" id="flotDashSales1" class="chart-active"></div>
									<script>
										var flotDashSales1Data = [{
											data: [
												["Jan", 140],
												["Feb", 240],
												["Mar", 190],
												["Apr", 140],
												["May", 180],
												["Jun", 320],
												["Jul", 270],
												["Aug", 180]
											],
											color: "#0088cc"
										}];

										// See: assets/javascripts/dashboard/examples.dashboard.js for more settings.
									</script>

									<!-- Flot: Best seller -->
									<div class="chart chart-sm" data-sales-rel="Porto Drupal" id="flotDashSales2" class="chart-hidden"></div>
									<script>
										var flotDashSales2Data = [{
											data: [
												["Jan", 240],
												["Feb", 240],
												["Mar", 290],
												["Apr", 540],
												["May", 480],
												["Jun", 220],
												["Jul", 170],
												["Aug", 190]
											],
											color: "#2baab1"
										}];

										// See: assets/javascripts/dashboard/examples.dashboard.js for more settings.
									</script>
								</div>

							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>