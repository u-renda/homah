<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left">

    <div class="sidebar-header">
        <div class="sidebar-title">
            MENU UTAMA
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>

    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <!-- <li class="nav-active"> -->
                    <li class="list-group-item2 panel-default">
                        <a href="<?= base_url('dashboard'); ?>">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="list-group-item2 panel-default">
                        <a href="<?= base_url('supplier'); ?>">
                            <i class="fa fa-truck" aria-hidden="true"></i>
                            <span>Pemasok</span>
                        </a>
                    </li>
                    <li class="nav-parent panel-default">
                        <a>
                            <i class="fa fa-archive" aria-hidden="true"></i>
                            <span>Produk</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="list-group-item2">
                                <a href="<?= base_url('product_category'); ?>">
                                    Kategori
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('product_brand'); ?>">
                                    Merek
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('product_item'); ?>">
                                    Barang
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('upload_new_item'); ?>">
                                    Upload Barang Baru
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('print_barcode'); ?>">
                                    Print Barcode
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent panel-default">
                        <a>
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            <span>Transaksi</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="list-group-item2">
                                <a href="<?= base_url('transaction_sales'); ?>">
                                    Penjualan
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('transaction_stockin'); ?>">
                                    Stok Masuk
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('transaction_stockout'); ?>">
                                    Stok Keluar
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent panel-default">
                        <a>
                            <i class="fa fa-bar-chart-o" aria-hidden="true"></i>
                            <span>Laporan</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="list-group-item2">
                                <a href="<?= base_url('report_sales'); ?>">
                                    Penjualan
                                </a>
                            </li>
                            <li class="list-group-item2">
                                <a href="<?= base_url('report_stock'); ?>">
                                    Stok Masuk/Keluar
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-header">
                <div class="sidebar-title">
                    PENGATURAN
                </div>
            </div>

            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <?php if (session()->get('level') == 'admin') { ?>
                    <li class="list-group-item2 panel-default">
                        <a href="<?= base_url('user'); ?>">
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Pengguna</span>
                        </a>
                    </li>
                    <?php } ?>
                    <li class="list-group-item2 panel-default">
                        <a href="<?= base_url('my_profile'); ?>">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span>Akun Saya</span>
                        </a>
                    </li>
                    <li class="list-group-item2 panel-default">
                        <a href="<?= base_url('setting'); ?>">
                            <i class="fa fa-cog" aria-hidden="true"></i>
                            <span>Konfigurasi</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</aside>
<!-- end: sidebar -->