<?php echo view('layout/header'); ?>
<?php echo view('layout/sidebar'); ?>
<?= $this->renderSection('content'); ?>
<?php echo view('layout/footer'); ?>