</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></span></button>
                <h4 class="modal-title" id="myModalLabel"></h4>
            </div>
            <div class="modal-body"></div>
        </div>
    </div>
</div>

</section>

<!-- Vendor -->
<script src="public/vendor/jquery/jquery.js"></script>
<script src="public/vendor/jquery/jquery-3.2.1.min.js"></script>
<script src="public/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="public/vendor/bootstrap/js/bootstrap.js"></script>
<script src="public/vendor/nanoscroller/nanoscroller.js"></script>
<script src="public/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="public/vendor/jquery-placeholder/jquery.placeholder.js"></script>

<!-- Specific Page Vendor -->
<script src="public/vendor/jquery-ui/js/jquery-ui-1.12.1.min.js"></script> <!-- autocomplete -->
<!-- <script src="public/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script> datepicker -->
<script src="public/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="public/vendor/flot/jquery.flot.js"></script>
<script src="public/vendor/flot/jquery.flot.categories.js"></script>
<script src="public/vendor/pnotify/pnotify.custom.js"></script>
<script src="public/vendor/select2/select2.js"></script>

<!-- DataTables -->
<script src="public/vendor/jquery-datatables/DataTables-1.10.22/js/jquery.dataTables.js"></script>
<script src="public/vendor/jquery-datatables/Buttons-1.6.5/js/dataTables.buttons.js"></script>
<script src="public/vendor/jquery-datatables/Buttons-1.6.5/js/buttons.flash.js"></script>
<script src="public/vendor/jquery-datatables/JSZip-2.5.0/jszip.js"></script>
<script src="public/vendor/jquery-datatables/pdfmake-0.1.36/pdfmake.js"></script>
<script src="public/vendor/jquery-datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script src="public/vendor/jquery-datatables/Buttons-1.6.5/js/buttons.html5.js"></script>
<script src="public/vendor/jquery-datatables/Buttons-1.6.5/js/buttons.print.js"></script>

<!-- Theme Base, Components and Settings -->
<script src="public/javascripts/theme.js"></script>

<!-- Theme Custom -->
<script src="public/js/app-origin.js"></script>
<script src="public/javascripts/theme.custom.js"></script>
<script src="public/js/app-table.js"></script>
<script src="public/js/app-table-btn.js"></script>

<!-- Theme Initialization Files -->
<script src="public/javascripts/theme.init.js"></script>

<!-- Examples -->
<script src="public/js/examples.dashboard.js"></script>
<script src="public/js/examples.datatables.ajax.js"></script>
</body>

</html>