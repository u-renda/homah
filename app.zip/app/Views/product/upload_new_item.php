<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Upload Barang Baru</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Produk</span></li>
				<li><span>Upload Barang Baru</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Upload Barang Baru</h2>
		</header>
		<div class="panel-body">
			<?php
			if(session()->getFlashdata('message')){
			?>
				<div class="alert alert-info">
					<?= session()->getFlashdata('message') ?>
				</div>
			<?php
			}
			?>
			<form method="post" action="<?= base_url('prosesExcel'); ?>" enctype="multipart/form-data">
				<div class="form-group">
					<label>File Excel</label>
					<input type="file" name="fileexcel" class="form-control" id="file" required accept=".xls, .xlsx" /></p>
				</div>
				<div class="form-group">
					<button class="btn btn-primary" type="submit">Upload</button>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>