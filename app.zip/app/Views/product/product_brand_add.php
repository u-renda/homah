<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Merek</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Produk</span></li>
				<li><span>Merek</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Tambah Merek Produk</h2>
		</header>
		<div class="panel-body">
			<form class="form-horizontal" method="post" action="<?= base_url('product_brand_add'); ?>">
				<?= csrf_field(); ?>
				<fieldset class="mb-xl">
					<div class="form-group">
						<label class="col-md-3 control-label">Nama</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="name" required>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('name') . '</span>';
							endif; ?>
						</div>
					</div>
				</fieldset>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-9 col-md-offset-3">
							<button type="submit" class="btn btn-primary">Simpan</button>
							<a href="<?= base_url('product_brand'); ?>">
								<button type="button" class="btn btn-default">Batal</button>
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>