<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Barang</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Produk</span></li>
				<li><span>Barang</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Tambah Barang</h2>
		</header>
		<div class="panel-body">
			<form class="form-horizontal" method="post" action="<?= base_url('product_item_add'); ?>">
				<?= csrf_field(); ?>
				<fieldset class="mb-xl">
					<div class="form-group">
						<label class="col-md-3 control-label">Barcode</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="barcode">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('barcode') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Nama</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="name" required>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('name') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Ukuran</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="size">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('size') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Kategori</label>
						<div class="col-md-8">
							<select class="form-control mb-md" name="id_product_category" required>
								<?php foreach ($category as $row) { 
									echo '<option value="'.$row->id_product_category.'"'.set_select('id_product_category', $row->id_product_category).'>'.ucwords($row->name).'</option>';
								} 
								if (isset($validation)) :
									echo '<span class="text-danger">' . $validation->getError('id_product_category') . '</span>';
								endif; ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Merek</label>
						<div class="col-md-8">
							<select class="form-control mb-md" name="id_product_brand" required>
								<?php foreach ($brand as $row) { 
									echo '<option value="'.$row->id_product_brand.'"'.set_select('id_product_brand', $row->id_product_brand).'>'.ucwords($row->name).'</option>';
								} 
								if (isset($validation)) :
									echo '<span class="text-danger">' . $validation->getError('id_product_brand') . '</span>';
								endif; ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Harga</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="price" required>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('price') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Stok</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="stock">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('stock') . '</span>';
							endif; ?>
						</div>
					</div>
				</fieldset>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-9 col-md-offset-3">
							<button type="submit" class="btn btn-primary">Simpan</button>
							<a href="<?= base_url('product_item'); ?>">
								<button type="button" class="btn btn-default">Batal</button>
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>