<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>HomaH - Print Barcode</title>
    <meta name="keywords" content="HomaH" />
    <meta name="description" content="HomaH">
    <meta name="author" content="HomaH">
    <link rel="icon" href="img/Homah-Logo.png">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
</head>

<body>
    <!-- start: page -->
    <table border="1" cellpadding="3" cellspacing="1">
        <?php foreach ($allData as $row) { ?>
            <img alt="<?= $row->barcode; ?>" src="vendor/barcode/Barcode.php?text=<?= $row->barcode; ?>&print=true&size=40"><br />
        <?php } ?>
    </table>
    <!-- end: page -->
</body>

</html>