<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Stok Masuk</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Transaksi</span></li>
				<li><span>Stok Masuk</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Tambah Stok Masuk</h2>
		</header>
		<div class="panel-body" id="page_transaction_stockin_add">
			<form class="form-horizontal" method="post" action="<?= base_url('transaction_stockin_add'); ?>">
				<?= csrf_field(); ?>
				<fieldset class="mb-xl">
					<div class="form-group">
						<label class="col-md-3 control-label">No. Invoice</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="invoice" value="<?php echo $invoice_no; ?>" required>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('invoice') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Tanggal</label>
						<div class="col-md-8">
							<!-- <div class="input-group date date-picker"> -->
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
								<input type="date" class="form-control" name="datein" id="datein" required>
								<?php if (isset($validation)) :
									echo '<span class="text-danger">' . $validation->getError('datein') . '</span>';
								endif; ?>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Nama Supplier</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="supplier_name" id="supplier_name" required>
							<input type="hidden" class="form-control" name="id_supplier" id="id_supplier">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('supplier_name') . '</span>';
							endif; ?>
						</div>
					</div>
					<?php for ($i=1;$i<=5;$i++) { ?>
					<div class="row">
						<label class="col-md-2 control-label">Nama Barang</label>
						<div class="col-md-3 mb-md">
							<input type="text" class="form-control" name="item_name<?php echo $i; ?>" id="item_name<?php echo $i; ?>">
							<input type="hidden" class="form-control" name="id_product_item<?php echo $i; ?>" id="id_product_item<?php echo $i; ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('item_name'.$i) . '</span>';
							endif; ?>
						</div>
						<label class="col-md-1 control-label">Jumlah</label>
						<div class="col-md-1">
							<input type="text" class="form-control" name="quantity<?php echo $i; ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('quantity'.$i) . '</span>';
							endif; ?>
						</div>
						<label class="col-md-1 control-label">Harga</label>
						<div class="col-md-3">
							<input type="text" class="form-control" name="price<?php echo $i; ?>" value="0">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('price'.$i) . '</span>';
							endif; ?>
						</div>
					</div>
					<?php } ?>
				</fieldset>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-9 col-md-offset-3">
							<button type="submit" class="btn btn-primary">Simpan</button>
							<a href="<?= base_url('transaction_stockin'); ?>">
								<button type="button" class="btn btn-default">Batal</button>
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>