<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Stok Keluar</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="index.html">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Transaksi</span></li>
				<li><span>Stok Keluar</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Data Stok Keluar</h2>
		</header>
		<div class="panel-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="mb-md">
						<button id="addToTable" class="btn btn-primary">Tambah <i class="fa fa-plus"></i></button>
					</div>
				</div>
			</div>
			<table class="table table-bordered table-striped mb-none" id="datatable-editable">
				<thead>
					<tr>
						<th>#</th>
						<th>Barcode</th>
						<th>Nama Barang</th>
						<th>Kuantitas</th>
						<th>Tanggal</th>
						<th>Tindakan</th>
					</tr>
				</thead>
				<tbody>
					<tr class="gradeX">
						<td>1</td>
						<td>Internet
							Explorer 4.0
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeC">
						<td>2</td>
						<td>Internet
							Explorer 5.0
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>3</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>4</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>5</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>6</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>7</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>8</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>9</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>10</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
					<tr class="gradeA">
						<td>11</td>
						<td>Internet
							Explorer 5.5
						</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td>Win 95+</td>
						<td class="actions">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>