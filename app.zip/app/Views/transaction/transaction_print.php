<?php
try {
    $printer -> setJustification(Printer::JUSTIFY_CENTER);
    $printer -> text("UD. KANAMART \n");
    $printer -> text("JL. WARUNG WINGIN NO. 9\n");
    $printer -> text("-----------------------------\n");
    $printer -> text("KASIR : AYU SEPTIANI|".date('Y:m:d h:i:s')." \n");
    $printer -> text("NO TRANSAKSI : 0009912220191122 \n");
    $printer -> text("-----------------------------\n");

    //potong kertas
    $printer -> cut();

    /* Close printer */
    $printer -> close();
} catch(Exception $e) {
    echo "TIDAK TERKONEKSI DENGAN PRINTER: " . $e -> getMessage() . "\n";
}