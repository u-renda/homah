<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Penjualan</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Transaksi</span></li>
				<li><span>Penjualan</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<div class="row" id="page_transaction_sales">
		<div class="col-md-4">
			<form id="form1" class="form-horizontal">
				<section class="panel">
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-4 control-label">Tanggal </label>
							<div class="col-sm-8">
								<input id="inputDisabled" type="text" name="tgl" class="form-control" value="<?= date('d-m-Y'); ?>" disabled>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Kasir </label>
							<div class="col-sm-8">
								<input id="inputDisabled" type="text" name="kasir" class="form-control" value="<?= session()->get('name'); ?>" disabled>
							</div>
						</div>
					</div>
				</section>
			</form>
		</div>
		<div class="col-md-4">
			<form id="form1" class="form-horizontal" method="post" action="<?= base_url('transaction_cart'); ?>">
				<section class="panel">
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-4 control-label">Barcode </label>
							<div class="col-sm-8">
								<div class="input-group">
									<input type="text" name="barcode" class="form-control" autofocus>
									<span class="input-group-btn">
										<button class="btn btn-info" type="submit"><i class="fa fa-search"></i></button>
									</span>
								</div>
							</div>
						</div>
					</div>
				</section>
			</form>
		</div>
		<div class="col-md-4">
			<section class="panel">
				<div class="panel-body">
					<p class="text-right">Receipt No: <strong class="text-dark"><?= $receiptNo; ?></strong></p>
					<?php 
					$subtotal = 0;
					if (session()->has('cart')) {
						foreach (session()->get('cart') as $row3) { 
							$subtotal += $row3['qty']*$row3['price'];
						} 
					} ?>
					<h1 class="text-right text-dark text-bold"><?= 'Rp '.number_format($subtotal, 0, ',', '.'); ?></h1>
				</div>
			</section>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<section class="panel">
				<div class="panel-body">
					<form method="post" action="<?= base_url('transaction_cart_update'); ?>">
						<table class="table table-bordered table-striped mb-none" id="datatable-editable">
							<thead>
								<tr>
									<th>#</th>
									<th>Nama Barang</th>
									<th>Harga</th>
									<th>Kuantitas</th>
									<th>Total</th>
									<th>Tindakan</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 0;
								if (session()->has('cart')) {
									foreach (session()->get('cart') as $row2) { ?>
										<tr class="gradeX">
											<td><?= $i+1; ?></td>
											<td><?= $row2['name']; ?></td>
											<td align="right"><?= number_format($row2['price'],0,",","."); ?></td>
											<td class="col-md-2">
												<input type="number" name="qty[]" value="<?= $row2['qty']; ?>" class="form-control">
											</td>
											<td align="right"><?= number_format($row2['price']*$row2['qty'],0,",","."); ?></td>
											<td class="actions">
												<a href="<?= base_url('transaction_cart_delete?id='.$row2['id_product_item']); ?>">
													<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger"><i class="fa fa-trash-o"></i> Hapus</button>
												</a>
											</td>
										</tr>
									<?php 
									$i++;
									} 
								} ?>
							</tbody>
						</table>
						<button type="submit" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary">Update</button>
					</form>
				</div>
			</section>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3">
			<section class="panel">
				<div class="panel-body">
					<div class="form-group">
						<label class="control-label">Pembayaran</label>
						<select class="form-control mb-md" name="payment_type" id="payment_type">
							<?php 
							foreach ($pembayaran as $row) {
								echo '<option value="' . $row->id_config_detail . '">' . $row->name . '</option>';
							} ?>
						</select>
					</div>
				</div>
			</section>
		</div>
		<div class="col-md-3">
			<form method="post" action="<?= base_url('transaction_cart_count'); ?>">
				<section class="panel">
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-4 control-label">Bayar</label>
							<div class="col-sm-8">
								<input type="text" name="cash" class="form-control right" value="<?= number_format(session()->get('cash'),0,",","."); ?>">
								<input type="hidden" name="subtotal" class="form-control" value="<?= $subtotal; ?>">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-8 col-sm-offset-4">
								<button type="submit" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary">Hitung</button>
							</div>
						</div>
					</div>
				</section>
			</form>
		</div>
		<div class="col-md-3">
			<form id="form1" class="form-horizontal">
				<section class="panel">
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-4 control-label">Kembalian </label>
							<div class="col-sm-8">
								<input id="inputDisabled" type="text" name="changes" class="form-control right" value="<?= number_format(session()->get('changes'),0,",","."); ?>" disabled>
							</div>
						</div>
					</div>
				</section>
			</form>
		</div>
		<div class="col-md-3">
			<section class="panel">
				<div class="panel-body">
					<p class="m-none">
						<a href="<?= base_url('transaction_cart_reset'); ?>">
							<button type="button" class="mb-xs mt-xs mr-xs btn btn-sm btn-warning"><i class="fa fa-refresh"></i> Batal/Reset</button>
						</a>
					</p>
					<form method="post" action="<?= base_url('transaction_process'); ?>">
						<input type="hidden" name="receiptNo" value="<?= $receiptNo; ?>">
						<input type="hidden" name="total" value="<?= $subtotal; ?>">
						<input type="hidden" name="payment_type2" id="payment_type2" value="">
						<p class="m-none">
							<button type="submit" class="mb-xs mt-xs mr-xs btn btn-lg btn-success"><i class="fa fa-send"></i> Print </button>
						</p>
					</form>
				</div>
			</section>
		</div>
	</div>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>