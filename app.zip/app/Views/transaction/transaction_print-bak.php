<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>HomaH - Print Sales</title>
    <meta name="keywords" content="HomaH" />
    <meta name="description" content="HomaH">
    <meta name="author" content="HomaH">
    <link rel="icon" href="public/img/Homah-Logo.png">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
</head>

<body>
    <!-- start: page -->
    <table width="100%">
        <tr>
            <td align="center"><img src="public/img/Homah-Logo-2-bw.png" width="20%"></td>
        </tr>
        <tr>
            <td align="center">Ruko Apartemen Serpong Green View RK03A</td>
        </tr>
        <tr>
            <td align="center">Jl. Lengkong Gudang Timur Raya</td>
        </tr>
        <tr>
            <td align="center">Lengkong Gudang Timur 15310</td>
        </tr>
        <tr>
            <td align="center">Phone 0878 7710 0071</td>
        </tr>
    </table>
    -----------------------------------------------------------------------------------------------------------------------------------------------------
    <table width="100%">
        <tr>
            <td colspan=2>Receipt No : <?= $receiptNo; ?></td>
        </tr>
        <tr>
            <td><?= $dateSales; ?></td>
            <td><?= $cashierName; ?></td>
        </tr>
    </table>
    <hr>
    <table width="100%">
        <?php foreach ($detail as $row) { ?>
        <tr>
            <td><?= $row['qty']; ?></td>
            <td>x</td>
            <td><?= $row['productItem']; ?></td>
            <td align="right"><?= $row['total']; ?></td>
        </tr>
        <?php } ?>
        <tr>
            <td colspan=4><hr></td>
        </tr>
        <tr>
            <td colspan=3>Total</td>
            <td align="right"><?= $total; ?></td>
        </tr>
        <tr>
            <td colspan=3><?= $payment_type; ?></td>
            <td align="right"><?= $payment; ?></td>
        </tr>
        <tr>
            <td colspan=3>Kembalian</td>
            <td align="right"><?= $payment_change; ?></td>
        </tr>
    </table>
    <hr>
    <table width="100%">
        <tr>
            <td>http://homah-indonesia.com</td>
        </tr>
        <tr>
            <td>homah.indonesia@gmail.com</td>
        </tr>
    </table>
    <!-- end: page -->
</body>

</html>