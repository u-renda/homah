<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Laporan Penjualan</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="index.html">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Laporan</span></li>
				<li><span>Penjualan</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Filter Data</h2>
		</header>
		<div class="panel-body">
			<form class="form-inline">
				<div class="form-group">
					<label>Tanggal </label>
					<input type="text" name="name" class="form-control">
				</div>
				<div class="form-group">
					<label>s/d </label>
					<input type="text" name="name" class="form-control">
				</div>
			</form>
		</div>
		<footer class="panel-footer">
			<div class="row">
				<div class="col-sm-12 text-right">
					<button class="btn btn-default">Reset</button>
					<button class="btn btn-primary"><i class="fa fa-search"></i> Filter</button>
				</div>
			</div>
		</footer>
	</section>
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Data Penjualan</h2>
		</header>
		<div class="panel-body">
			<table class="display" id="datatable-ajax" data-url="<?= base_url('report_sales_get'); ?>" style="width: 100%;">
				<thead>
					<tr>
						<th>#</th>
						<th>Tanggal</th>
						<th>Kasir</th>
						<th>Receipt No.</th>
						<th>Total</th>
						<th>Pembayaran</th>
						<th>Tindakan</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>#</th>
						<th>Tanggal</th>
						<th>Kasir</th>
						<th>Receipt No.</th>
						<th>Total</th>
						<th>Pembayaran</th>
						<th>Tindakan</th>
					</tr>
				</tfoot>
			</table>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>