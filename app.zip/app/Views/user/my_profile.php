<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Akun Saya</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="index.html">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Akun Saya</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<div class="panel-body">
			<?php 
			if (is_null(session()->getFlashdata('success')) == 0) : ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<?= session()->getFlashdata('success'); ?>
				</div>
			<?php elseif (is_null(session()->getFlashdata('error')) == 0): ?>
				<div class="alert alert-error">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<?= session()->getFlashdata('error'); ?>
				</div>
			<?php endif; ?>
			<form class="form-horizontal" method="post" action="<?= base_url('my_profile_edit'); ?>">
				<?= csrf_field(); ?>
				<h4 class="mb-xlg">Data Pribadi</h4>
				<fieldset>
					<div class="form-group">
						<label class="col-md-3 control-label">Nama</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="name" value="<?= set_value('name', $allData->name); ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('name') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Username</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="username" value="<?= set_value('username', $allData->username); ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('username') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Telp</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="telp" value="<?= set_value('telp', $allData->telp); ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('telp') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Level</label>
						<div class="col-md-8">
							<select class="form-control mb-md" name="level" required>
								<?php foreach ($code_level as $key => $val) {  ?>
									<option value="<?php echo $key; ?>" <?php if ($allData->level == $key) { echo 'selected="selected"'; } echo set_select('level', $key); ?>><?php echo ucwords($val); ?></option>
								<?php 
								} 
								if (isset($validation)) :
									echo '<span class="text-danger">' . $validation->getError('level') . '</span>';
								endif; ?>
							</select>
						</div>
					</div>
				</fieldset>
				<hr class="dotted tall">
				<h4 class="mb-xlg">Ubah Password</h4>
				<fieldset class="mb-xl">
					<div class="form-group">
						<label class="col-md-3 control-label">Password Baru</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="new_password">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('new_password') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Ulangi Password Baru</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="repeat_password">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('repeat_password') . '</span>';
							endif; ?>
						</div>
					</div>
				</fieldset>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-9 col-md-offset-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary">Simpan</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>