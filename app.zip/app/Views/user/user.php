<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Pengguna</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="index.html">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Pengguna</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Data Pengguna</h2>
		</header>
		<div class="panel-body">
			<div class="row" id="page_transaction_stockin">
				<div class="col-sm-12">
					<?php 
					if (is_null(session()->getFlashdata('success')) == 0) : ?>
						<div class="alert alert-success">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<?= session()->getFlashdata('success'); ?>
						</div>
					<?php elseif (is_null(session()->getFlashdata('error')) == 0): ?>
						<div class="alert alert-error">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<?= session()->getFlashdata('error'); ?>
						</div>
					<?php endif; ?>
				</div>
				<div class="col-sm-6">
					<div class="mb-md">
						<a href="<?= base_url('user_add'); ?>">
							<button class="btn btn-primary">Tambah <i class="fa fa-plus"></i></button>
						</a>
					</div>
				</div>
			</div>
			<table class="display" id="datatable-ajax" data-url="<?= base_url('user_get'); ?>" style="width: 100%;">
				<thead>
					<tr>
						<th>#</th>
						<th>Username</th>
						<th>Nama</th>
						<th>Telp</th>
						<th>Level</th>
						<th>Tindakan</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>#</th>
						<th>Username</th>
						<th>Nama</th>
						<th>Telp</th>
						<th>Level</th>
						<th>Tindakan</th>
					</tr>
				</tfoot>
			</table>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>