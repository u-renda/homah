<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Supplier</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span>Supplier</span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title">Ubah Supplier</h2>
		</header>
		<div class="panel-body">
			<form class="form-horizontal" method="post" action="<?= base_url('supplier_edit?id='.$allData->id_supplier); ?>">
				<?= csrf_field(); ?>
				<?php //print_r($allData);die(); ?>
				<fieldset class="mb-xl">
					<div class="form-group">
						<label class="col-md-3 control-label">Nama</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="name" value="<?= set_value('name', $allData->name) ?>" required>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('name') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Telp</label>
						<div class="col-md-8">
							<input type="text" class="form-control" name="telp" value="<?= set_value('telp', $allData->telp) ?>">
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('telp') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Alamat</label>
						<div class="col-md-8">
							<textarea class="form-control" name="address"><?= set_value('address', $allData->address) ?></textarea>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('address') . '</span>';
							endif; ?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Keterangan</label>
						<div class="col-md-8">
						<textarea class="form-control" name="description"><?= set_value('description', $allData->description) ?></textarea>
							<?php if (isset($validation)) :
								echo '<span class="text-danger">' . $validation->getError('description') . '</span>';
							endif; ?>
						</div>
					</div>
				</fieldset>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-9 col-md-offset-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary">Simpan</button>
							<a href="<?= base_url('supplier'); ?>">
								<button type="button" class="btn btn-default">Batal</button>
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>