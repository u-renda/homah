<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<section role="main" class="content-body">
	<header class="page-header">
		<h2>Konfigurasi</h2>

		<div class="right-wrapper pull-right">
			<ol class="breadcrumbs">
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fa fa-home"></i>
					</a>
				</li>
				<li><span><?= $pageTitle; ?></span></li>
			</ol>

			<span class="sidebar-right-toggle"></span>
		</div>
	</header>

	<!-- start: page -->
	<section class="panel">
		<header class="panel-heading">
			<h2 class="panel-title"><?= $pageTitle; ?></h2>
		</header>
		<div class="panel-body">
			<div class="row" id="page_config_detail">
				<div class="col-sm-12">
					<?php 
					if (is_null(session()->getFlashdata('success')) == 0) : ?>
						<div class="alert alert-success">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<?= session()->getFlashdata('success'); ?>
						</div>
					<?php elseif (is_null(session()->getFlashdata('error')) == 0): ?>
						<div class="alert alert-error">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<?= session()->getFlashdata('error'); ?>
						</div>
					<?php endif; ?>
				</div>
				<div class="col-sm-6">
					<div class="mb-md">
						<a href="<?= base_url('config_type_add'); ?>">
							<button class="btn btn-primary">Tambah <i class="fa fa-plus"></i></button>
						</a>
						<a href="<?= base_url('setting'); ?>">
							<button type="button" class="btn btn-default">Kembali</button>
						</a>
					</div>
				</div>
			</div>
			<table class="display" id="datatable-ajax" data-url="<?= base_url('config_detail_get?id='.$id); ?>" style="width: 100%;">
				<thead>
					<tr>
						<th>#</th>
						<th>Detail</th>
						<th>Tindakan</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>#</th>
						<th>Detail</th>
						<th>Tindakan</th>
					</tr>
				</tfoot>
			</table>
		</div>
	</section>
	<!-- end: page -->
</section>
<?= $this->endSection(); ?>