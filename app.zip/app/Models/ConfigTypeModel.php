<?php

namespace App\Models;

use CodeIgniter\Model;

class ConfigTypeModel extends Model
{
    protected $table = 'config_type';
    protected $primaryKey = 'id_config_type';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',name,description')
            ->orderBy('name', 'ASC');

        return $builder->get();
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['name'])) {
            $where += array('name' => $param['name']);
        }

        $builder->select($this->primaryKey . ',name,description')
            ->where($where);

        return $builder->get();
    }

    public function countAll()
    {
        return $this->countAllResults();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);
        $id = $db->insertID();

        return $id;
    }
}
