<?php

namespace App\Models;

use CodeIgniter\Model;

class SupplierModel extends Model
{
    protected $table = 'supplier';
    protected $primaryKey = 'id_supplier';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',name,telp,address,description')
            ->orderBy('name', 'ASC');

        return $builder->get();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);

        return $query;
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }

        $builder->select($this->primaryKey . ',name,telp,address,description')
            ->where($where);

        return $builder->get();
    }

    public function getSearch($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $like = array();
        if (isset($param['name'])) {
            $like += array('name' => $param['name']);
            
        }

        $builder->select($this->primaryKey . ',name')
            ->like($like);

        return $builder->get();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->updatedField] = date('Y-m-d H:i:s');

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }
}
