<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'id_user';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',id_store,username,name,telp,level')
            ->orderBy('name', 'ASC');

        return $builder->get();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);

        return $query;
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['username'])) {
            $where += array('username' => $param['username']);
        }
        if (isset($param['password'])) {
            $where += array('password' => md5($param['password']));
        }
        
        $builder->select($this->primaryKey . ',id_store,username,name,telp,level,password')
            ->where($where);

        return $builder->get();
    }

    public function getSearch($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $like = array();
        if (isset($param['name'])) {
            $like += array('name' => $param['name']);
            
        }

        $builder->select($this->primaryKey . ',name')
            ->like($like);

        return $builder->get();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }
}
