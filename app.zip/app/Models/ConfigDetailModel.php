<?php

namespace App\Models;

use CodeIgniter\Model;

class ConfigDetailModel extends Model
{
    protected $table = 'config_detail';
    protected $primaryKey = 'id_config_detail';
    protected $useTimestamps = true;
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['id_config_type'])) {
            $where += array('id_config_type' => $param['id_config_type']);
        }
        if (isset($param['name'])) {
            $where += array('name' => $param['name']);
        }

        $builder->select($this->primaryKey . ',id_config_type,name,updated_date')
            ->where($where);

        return $builder->get();
    }

    public function countAll()
    {
        return $this->countAllResults();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->updatedField] = date('Y-m-d H:i:s');

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }
}
