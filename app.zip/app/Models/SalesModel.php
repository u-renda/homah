<?php

namespace App\Models;

use CodeIgniter\Model;

class SalesModel extends Model
{
    protected $table = 'sales';
    protected $primaryKey = 'id_sales';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',id_user,date_sales,receipt_no,total,payment,payment_change,id_config_detail')
            ->orderBy('date_sales', 'DESC');

        return $builder->get();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);
        $id = $db->insertID();

        return $id;
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['date_sales'])) {
            $where += array('date_sales' => $param['date_sales']);
        }
        
        $builder->select($this->primaryKey . ',id_user,date_sales,receipt_no,total,payment,payment_change,id_config_detail,'.$this->createdField)
            ->where($where);

        return $builder->get();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->updatedField] = date('Y-m-d H:i:s');

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }
}
