<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductCategoryModel extends Model
{
    protected $table = 'product_category';
    protected $primaryKey = 'id_product_category';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',name')
            ->orderBy('name', 'ASC');

        return $builder->get();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);
        $id = $db->insertID();

        return $id;
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['name'])) {
            $where += array('name' => strtoupper($param['name']));
        }

        $builder->select($this->primaryKey . ',name')
            ->where($where);

        return $builder->get();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->updatedField] = date('Y-m-d H:i:s');

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }
}
