<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductItemModel extends Model
{
    protected $table = 'product_item';
    protected $primaryKey = 'id_product_item';
    protected $createdField  = 'created_date';
    protected $updatedField  = 'updated_date';

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $builder->select($this->primaryKey . ',id_product_category,id_product_brand,barcode,name,price,stock,size,purchase_price')
            ->orderBy('name', 'ASC');

        return $builder->get();
    }

    public function insertData($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->primaryKey] = 'UUID_SHORT()';
        $param[$this->createdField] = date('Y-m-d H:i:s');
        $param[$this->updatedField] = date('Y-m-d H:i:s');
        $query = $builder->insert($param);

        return $query;
    }

    public function getInfo($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $where = array();
        if (isset($param['id'])) {
            $where += array($this->primaryKey => $param['id']);
        }
        if (isset($param['id_product_category'])) {
            $where += array('id_product_category' => $param['id_product_category']);
        }
        if (isset($param['id_product_brand'])) {
            $where += array('id_product_brand' => $param['id_product_brand']);
        }
        if (isset($param['name'])) {
            $where += array('name' => strtoupper($param['name']));
        }
        if (isset($param['barcode'])) {
            $where += array('barcode' => $param['barcode']);
        }
        if (isset($param['stock_exist'])) {
            $where += array('stock !=' => $param['stock_exist']);
        }

        $builder->select($this->primaryKey . ',id_product_category,id_product_brand,barcode,name,price,stock,size,purchase_price')
            ->where($where);

        return $builder->get();
    }

    public function updateData($param, $id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $param[$this->updatedField] = date('Y-m-d H:i:s');

        $query = $builder->update($param, [$this->primaryKey => $id]);

        return $query;
    }

    public function getSearch($param)
    {
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);

        $like = array();
        if (isset($param['name'])) {
            $like += array('name' => $param['name']);
            
        }

        $builder->select($this->primaryKey . ',name')
            ->like($like);

        return $builder->get();
    }
}
