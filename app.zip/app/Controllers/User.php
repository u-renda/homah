<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\StoreModel;

class User extends BaseController
{
	protected $UserModel;
	protected $StoreModel;

	public function __construct()
	{
		$this->UserModel = new UserModel();
		$this->StoreModel = new StoreModel();
	}

	public function index()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Pengguna';

		return view('user/user', $data);
	}

	public function my_profile()
	{
		$query = $this->UserModel->getInfo(array('username' => session()->get('username')));

		if (count($query->getResult()) > 0) {
			if ($this->request->getVar('submit')) {
				if ($this->request->getMethod() === 'post' && $this->validate(
					[
						'username' => 'required|is_unique[user.username,id_user,{id}]',
						'level' => 'required',
						'telp' => 'required',
						'name' => 'required'
					]
				)) {
					$param['username'] = $this->request->getVar('username');
					$param['level'] = $this->request->getVar('level');
					$param['name'] = $this->request->getVar('name');
					$param['telp'] = $this->request->getVar('telp');

					if ($this->request->getVar('new_password') != '' && $this->request->getVar('repeat_password') != '') {
						if (strtolower($this->request->getVar('new_password')) != strtolower($this->request->getVar('repeat_password'))) {
							$param['password'] = md5($this->request->getVar('new_password'));
						} else {
							session()->setFlashdata('error', 'Ulangi Password Baru tidak sama dengan Password Baru');
						}
					} else {
						session()->setFlashdata('error', 'Password baru dan ulangi password harus diisi');
					}
					
					$query4 = $this->ProductItemModel->updateData($param, $query->getRow()->id_user);

					if ($query4 == TRUE) {
						session()->setFlashdata('success', 'Data berhasil diubah');
					} else {
						session()->setFlashdata('error', 'Data gagal diubah');
					}

					return redirect()->route('product_item');
				} else {
					$data['validation'] = $this->validator;
				}
			}

			$data['allData'] = $query->getRow();
			$data['pageTitle'] = 'Akun Saya';
			$data['code_level'] = array(1 => "admin",2 => "kasir");

			echo view('user/my_profile', $data);
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function user_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->UserModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_user . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_user . '-edit" href="transaction_stockin_edit?id=' . $row->id_user . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
                <a title="Delete" id="' . $row->id_user . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_user . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			if ($row->level == 1) {
				$level = "Admin";
			} else {
				$level = "Kasir";
			}

			$query2 = $this->StoreModel->getInfo(array('id' => $row->id_store));
			$entry = [$i,$row->username,ucwords($row->name),$row->telp,$level,$action];
			
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}
}
