<?php

namespace App\Controllers;

use App\Models\ProductCategoryModel;
use App\Models\ProductBrandModel;
use App\Models\ProductItemModel;
use App\Models\ConfigTypeModel;
use App\Models\ConfigDetailModel;
use PHPExcel;
use PHPExcel_IOFactory;

class Product extends BaseController
{
	protected $ProductCategoryModel;
	protected $ProductBrandModel;
	protected $ProductItemModel;
	protected $ConfigTypeModel;
	protected $ConfigDetailModel;

	public function __construct()
	{
		$this->ProductCategoryModel = new ProductCategoryModel();
		$this->ProductBrandModel = new ProductBrandModel();
		$this->ProductItemModel = new ProductItemModel();
		$this->ConfigTypeModel = new ConfigTypeModel();
		$this->ConfigDetailModel = new ConfigDetailModel();
	}

	public function category()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Produk - Kategori';

		return view('product/product_category', $data);
	}

	public function brand()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Produk - Merek';

		return view('product/product_brand', $data);
	}

	public function item()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Produk - Barang';

		return view('product/product_item', $data);
	}

	public function category_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->ProductCategoryModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_product_category . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_product_category . '-edit" href="product_category_edit?id=' . $row->id_product_category . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
                        <a title="Delete" id="' . $row->id_product_category . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_product_category . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			$entry = [$i,ucwords($row->name), $action];
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function category_add()
	{
		if ($this->request->getMethod() === 'post' && $this->validate(
			[
				'name' => 'required|is_unique[product_category.name]'
			],
			[
				// Errors
				'name' => [
					'is_unique' => 'Nama {value} sudah terdaftar'
				]
			]
		)) {
			$param['name'] = $this->request->getVar('name');

			$query = $this->ProductCategoryModel->insertData($param);

			session()->setFlashdata('success', 'Data berhasil ditambahkan');

			return redirect()->route('product_category');
		} else {
			$data['validation'] = $this->validator;
		}

		$data['pageTitle'] = 'Kategori Produk - Tambah';

		echo view('product/product_category_add', $data);
	}

	public function category_delete()
	{
		$data = array();
		$data['id'] = $this->request->getVar('id');
		$data['action'] = $this->request->getVar('action');
		$data['grid'] = 'datatable-ajax';

		$query = $this->ProductCategoryModel->getInfo(array('id' => $data['id']));

		if (count($query->getResult()) > 0) {
			if ($this->request->getVar('delete')) {
				$query2 = $this->ProductCategoryModel->delete($data['id']);

				if ($query2 == TRUE) {
					$response =  array('msg' => 'Hapus data berhasil', 'type' => 'success');
				} else {
					$response =  array('msg' => 'Hapus data gagal', 'type' => 'error');
				}

				echo json_encode($response);
				exit();
			} else {
				echo view('layout/page_delete', $data);
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function brand_delete()
	{
		$data = array();
		$data['id'] = $this->request->getVar('id');
		$data['action'] = $this->request->getVar('action');
		$data['grid'] = 'datatable-ajax';

		$query = $this->ProductBrandModel->getInfo(array('id' => $data['id']));

		if (count($query->getResult()) > 0) {
			if ($this->request->getVar('delete')) {
				$query2 = $this->ProductBrandModel->delete($data['id']);

				if ($query2 == TRUE) {
					$response =  array('msg' => 'Hapus data berhasil', 'type' => 'success');
				} else {
					$response =  array('msg' => 'Hapus data gagal', 'type' => 'error');
				}

				echo json_encode($response);
				exit();
			} else {
				echo view('layout/page_delete', $data);
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function item_delete()
	{
		$data = array();
		$data['id'] = $this->request->getVar('id');
		$data['action'] = $this->request->getVar('action');
		$data['grid'] = 'datatable-ajax';

		$query = $this->ProductItemModel->getInfo(array('id' => $data['id']));

		if (count($query->getResult()) > 0) {
			if ($this->request->getVar('delete')) {
				$query2 = $this->ProductItemModel->delete($data['id']);

				if ($query2 == TRUE) {
					$response =  array('msg' => 'Hapus data berhasil', 'type' => 'success');
				} else {
					$response =  array('msg' => 'Hapus data gagal', 'type' => 'error');
				}

				echo json_encode($response);
				exit();
			} else {
				echo view('layout/page_delete', $data);
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function category_edit()
	{
		if ($this->request->getVar('id') != ''){
			$id = $this->request->getVar('id');
			$query = $this->ProductCategoryModel->getInfo(array('id' => $id));

			if (count($query->getResult()) > 0) {
				if ($this->request->getVar('submit')) {
					if ($this->request->getMethod() === 'post' && $this->validate(
						[
							'name' => 'required|is_unique[product_category.name,id_product_category,{id}]'
						]
					)) {
						$param['name'] = $this->request->getVar('name');

						$query2 = $this->ProductCategoryModel->updateData($param, $id);

						if ($query2 == TRUE) {
							session()->setFlashdata('success', 'Data berhasil diubah');
						} else {
							session()->setFlashdata('error', 'Data gagal diubah');
						}

						return redirect()->route('product_category');
					} else {
						$data['validation'] = $this->validator;
					}
				}

				$data['allData'] = $query->getRow();
				$data['pageTitle'] = 'Kategori Produk - Ubah';

				echo view('product/product_category_edit', $data);
			} else {
				throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function brand_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->ProductBrandModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_product_brand . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_product_brand . '-edit" href="product_brand_edit?id=' . $row->id_product_brand . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
			<a title="Delete" id="' . $row->id_product_brand . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_product_brand . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			$entry = [$i, ucwords($row->name), $action];
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function brand_add()
	{
		if ($this->request->getMethod() === 'post' && $this->validate(
			[
				'name' => 'required|is_unique[product_brand.name]'
			],
			[
				// Errors
				'name' => [
					'is_unique' => 'Nama {value} sudah terdaftar'
				]
			]
		)) {
			$param['name'] = $this->request->getVar('name');

			$query = $this->ProductBrandModel->insertData($param);

			session()->setFlashdata('success', 'Data berhasil ditambahkan');

			return redirect()->route('product_brand');
		} else {
			$data['validation'] = $this->validator;
		}

		$data['pageTitle'] = 'Merek Produk - Tambah';

		echo view('product/product_brand_add', $data);
	}

	public function brand_edit()
	{
		if ($this->request->getVar('id') != ''){
			$id = $this->request->getVar('id');
			$query = $this->ProductBrandModel->getInfo(array('id' => $id));

			if (count($query->getResult()) > 0) {
				if ($this->request->getVar('submit')) {
					if ($this->request->getMethod() === 'post' && $this->validate(
						[
							'name' => 'required|is_unique[product_brand.name,id_product_brand,{id}]'
						]
					)) {
						$param['name'] = $this->request->getVar('name');

						$query2 = $this->ProductBrandModel->updateData($param, $id);

						if ($query2 == TRUE) {
							session()->setFlashdata('success', 'Data berhasil diubah');
						} else {
							session()->setFlashdata('error', 'Data gagal diubah');
						}

						return redirect()->route('product_brand');
					} else {
						$data['validation'] = $this->validator;
					}
				}

				$data['allData'] = $query->getRow();
				$data['pageTitle'] = 'Merek Produk - Ubah';

				echo view('product/product_brand_edit', $data);
			} else {
				throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function item_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->ProductItemModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_product_item . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_product_item . '-edit" href="product_item_edit?id=' . $row->id_product_item . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
                        <a title="Delete" id="' . $row->id_product_item . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_product_item . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			$query2 = $this->ProductCategoryModel->getInfo(array('id' => $row->id_product_category));
			$query3 = $this->ProductBrandModel->getInfo(array('id' => $row->id_product_brand));

			$productName = ucwords($row->name);

			// hapus nama yang gak ada mereknya
			if (strpos($row->name, '- | ') !== false) {
				$explode = explode('- | ',$row->name);
				$productName = ucwords($explode[1]);
			}

			$entry = [$i,$row->barcode,$productName,$row->size,ucwords($query2->getrow()->name),ucwords($query3->getrow()->name),number_format($row->purchase_price),number_format($row->price),$row->stock,$action];
			
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function item_add()
	{
		$query2 = $this->ProductCategoryModel->getAll();
		$query3 = $this->ProductBrandModel->getAll();

		$data['pageTitle'] = 'Data Barang - Tambah';
		$data['category'] = $query2->getresult();
		$data['brand'] = $query3->getresult();

		if ($this->request->getMethod() === 'post' && $this->validate(
			[
				'name' => 'required|is_unique[product_item.name]',
				'id_product_category' => 'required',
				'id_product_brand' => 'required',
				'price' => 'required'
			],
			[
				// Errors
				'name' => [
					'is_unique' => 'Nama {value} sudah terdaftar'
				]
			]
		)) {
			$param['id_product_category'] = $this->request->getVar('id_product_category');
			$param['id_product_brand'] = $this->request->getVar('id_product_brand');
			$param['name'] = $this->request->getVar('name');
			$param['price'] = $this->request->getVar('price');
			$param['barcode'] = $this->request->getVar('barcode');
			$param['size'] = $this->request->getVar('size');
			$param['stock'] = $this->request->getVar('stock');
			
            if ($this->request->getVar('barcode') == '') {
    			// generate barcode = 13 digit - terdiri dari merek dan kategori
    			$query4 = $this->ConfigTypeModel->getInfo(array('name' => 'auto number'));
    			$query5 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query4->getRow()->id_config_type));
    			$number = sprintf('%07d', $query5->getrow()->name);
    			$barcode = substr($param['id_product_category'],-3,3) . substr($param['id_product_brand'],-3,3) . $number;
    			$param['barcode'] = $barcode;
            }

			$query = $this->ProductItemModel->insertData($param);

			$update_number = $query5->getrow()->name + 1;
			$query6 = $this->ConfigDetailModel->updateData(array('name' => $update_number), $query5->getrow()->id_config_detail);

			session()->setFlashdata('success', 'Data berhasil ditambahkan');

			return redirect()->route('product_item');
		} else {
			$data['validation'] = $this->validator;
		}

		echo view('product/product_item_add', $data);
	}

	public function item_edit()
	{
		if ($this->request->getVar('id') != ''){
			$query2 = $this->ProductCategoryModel->getAll();
			$query3 = $this->ProductBrandModel->getAll();

			$data['category'] = $query2->getresult();
			$data['brand'] = $query3->getresult();

			$id = $this->request->getVar('id');
			$query = $this->ProductItemModel->getInfo(array('id' => $id));

			if (count($query->getResult()) > 0) {
				if ($this->request->getVar('submit')) {
					if ($this->request->getMethod() === 'post' && $this->validate(
						[
							'name' => 'required|is_unique[product_item.name,id_product_item,{id}]',
							'id_product_category' => 'required',
							'id_product_brand' => 'required',
							'price' => 'required',
							'barcode' => 'required'
						]
					)) {
						$param['id_product_category'] = $this->request->getVar('id_product_category');
						$param['id_product_brand'] = $this->request->getVar('id_product_brand');
						$param['name'] = $this->request->getVar('name');
						$param['price'] = $this->request->getVar('price');
						$param['barcode'] = $this->request->getVar('barcode');
						$param['size'] = $this->request->getVar('size');
						$param['stock'] = $this->request->getVar('stock');

						$query4 = $this->ProductItemModel->updateData($param, $id);

						if ($query4 == TRUE) {
							session()->setFlashdata('success', 'Data berhasil diubah');
						} else {
							session()->setFlashdata('error', 'Data gagal diubah');
						}

						return redirect()->route('product_item');
					} else {
						$data['validation'] = $this->validator;
					}
				}

				$data['allData'] = $query->getRow();
				$data['pageTitle'] = 'Data Barang - Ubah';

				//$barcode = new Barcode();
				//$data['testbarcode'] = $this->Barcode;
				//print_r($barcode);die();

				echo view('product/product_item_edit', $data);
			} else {
				throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
			}
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function upload_new_item()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Produk - Upload Barang Baru';

		return view('product/upload_new_item', $data);
	}
	
	public function prosesExcel()
	{
		$file = $this->request->getFile('fileexcel');

		if ($file) {
			$excelReader  = new PHPExcel();

			//mengambil lokasi temp file
			$fileLocation = $file->getTempName();

			//baca file
			$objPHPExcel = PHPExcel_IOFactory::load($fileLocation);

			//ambil sheet active
			$sheet	= $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);

			//looping untuk mengambil data
			foreach ($sheet as $idx => $data) {
				//skip index 1 karena title excel
				if ($idx == 1){
					continue;
				}

				$query6 = $this->ProductCategoryModel->getInfo(array('name' => strtoupper($data['A'])));

				if (count($query6->getResult()) > 0) {
					$query = $query6->getRow()->id_product_category;
				} else {
					$param['name'] = $data['A'];
					$query = $this->ProductCategoryModel->insertData($param);
				}

				$query7 = $this->ProductBrandModel->getInfo(array('name' => strtoupper($data['B'])));

				if (count($query7->getResult()) > 0) {
					$query2 = $query7->getRow()->id_product_brand;
				} else {
					$param2['name'] = $data['B'];
					$query2 = $this->ProductBrandModel->insertData($param2);
				}

				$param3 = array();
				$param3['id_product_category'] = $query;
				$param3['id_product_brand'] = $query2;
				$param3['name'] = $data['B'] ." | ". $data['C'];
				$query8 = $this->ProductItemModel->getInfo($param3);

				$param4 = array();
				if (count($query8->getResult()) > 0) {
					// continue;
					// update stock
					if ($data['E'] != '' && $query8->getRow()->stock == '') {
						$param4['stock'] = $data['E'];
					}
					
					// update harga modal
					if ($data['F'] != '' && $query8->getRow()->purchase_price == 0) {
						$param4['purchase_price'] = $data['F'];
					}
					
					// update harga jual
					if ($data['G'] != '' && $query8->getRow()->price == 0) {
						$param4['price'] = $data['G'];
					}

					if (count($param4) > 0) {
						$query9 = $this->ProductItemModel->updateData($param4,$query8->getRow()->id_product_item);
					}
				} else {
					// generate barcode = 13 digit - terdiri dari merek dan kategori
					$query4 = $this->ConfigTypeModel->getInfo(array('name' => 'auto number'));
					$query5 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query4->getRow()->id_config_type));
					$number = sprintf('%07d', $query5->getrow()->name);
					$barcode = substr($param3['id_product_category'],-3,3) . substr($param3['id_product_brand'],-3,3) . $number;

					if ($data['H'] != "") {
						$param3['barcode'] = $data['H'];

						$update_number = $query5->getrow()->name + 1;
						$query6 = $this->ConfigDetailModel->updateData(array('name' => $update_number), $query5->getrow()->id_config_detail);
					} else {
						$param3['barcode'] = $barcode;
					}

					// nama yang di insert ditambah nama mereknya
					$param3['size'] = $data['D'];
					$param3['stock'] = $data['E'];
					$param3['purchase_price'] = $data['F'];
					$param3['price'] = $data['G'];
					$query3 = $this->ProductItemModel->insertData($param3);
				}
			}
		}

		session()->setFlashdata('success', 'Data berhasil ditambahkan');
		return redirect()->route('product_item');
	}

	public function search_product_item()
	{
		$query = $this->ProductItemModel->getSearch(array('name' => $this->request->getVar('search')));

		$response = array();
		foreach ($query->getResult() as $row){
			$response[] = array("value"=>$row->id_product_item, "label" => $row->name);
		}
		
		echo json_encode($response);
	}

	public function print_barcode()
	{
		$query = $this->ProductItemModel->getAll();

		foreach ($query->getResult() as $row) {
			$substr = substr($row->barcode,-4);
			echo $row->barcode.'<br>';
		}
die;
		$query = $this->ProductItemModel->getInfo(array('stock_exist' => 0));

		$data['allData'] = $query->getResult();
		echo view('product/print_barcode', $data);
	}
}
