<?php

namespace App\Controllers;

use App\Models\ProductItemModel;
use App\Models\UserModel;
use App\Models\SupplierModel;
use App\Models\SalesModel;

class Home extends BaseController
{
	protected $ProductItemModel;

	public function __construct()
	{
		$this->ProductItemModel = new ProductItemModel();
		$this->UserModel = new UserModel();
		$this->SupplierModel = new SupplierModel();
		$this->SalesModel = new SalesModel();
	}

	public function index()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data = array();
		$data['todayIncome'] = 0;
		$income = 0;
		$income2 = 0;

		//hitung pendapatan hari ini
		$param = array();
		$param['date_sales'] = date('Y-m-d');

		$query4 = $this->SalesModel->getInfo($param);
		
		if (count($query4->getResult()) > 0) {
			foreach ($query4->getResult() as $row) {
				$income += $row->total;
			}

			$data['todayIncome'] = number_format($income,0,",",".");
		}
		
		//hitung pendapatan bulan ini
		$query5 = $this->SalesModel->getAll();

		if (count($query5->getResult()) > 0) {
			foreach ($query5->getResult() as $row) {
				$explode = explode("-",$row->date_sales);
				
				if ($explode[1] == date('m')) {
					$income2 += $row->total;
				}
			}

			$data['monthIncome'] = number_format($income2,0,",",".");
		}

		//hitung keuntungan bulan ini
		$query = $this->ProductItemModel->countAll();
		$query2 = $this->UserModel->countAll();
		$query3 = $this->SupplierModel->countAll();

		$data['totalItem'] = $query;
		$data['totalUser'] = $query2;
		$data['totalSupplier'] = $query3;
		$data['pageTitle'] = 'Dashboard';

		return view('dashboard', $data);
	}
}
