<?php

namespace App\Controllers;

use CodeIgniter\Config\Config;
use App\Models\UserModel;
use App\Models\StoreModel;

class Login extends BaseController
{
	protected $UserModel;
	protected $StoreModel;

	public function __construct()
	{
		$this->UserModel = new UserModel();
		$this->StoreModel = new StoreModel();
	}

	public function index()
	{
		//check session
		if ((session()->get('username'))) {
			return redirect()->to(base_url('dashboard'));
		}

		$query = $this->StoreModel->getAll();

		$data = [
			'store' => $query->getResult()
		];

		return view('login', $data);
	}

	public function process()
	{
		if ($this->request->getMethod() === 'post' && $this->validate([
			'username' => 'required',
			'password'  => 'required',
			'store'  => 'required'
		])) {
			$param['username'] = $this->request->getPost('username');
			$param['password'] = $this->request->getPost('password');

			$query = $this->UserModel->getInfo($param);

			$param['id_store'] = $this->request->getPost('store');

			if (count($query->getResult()) > 0) {
				if ($query->getRow()->level == 1) {
					$level = 'admin';
				} else {
					$level = 'kasir';

					if ($query->getRow()->id_store != $param['id_store']) {
						session()->setflashdata('error', 'Anda tidak punya akses ke toko ini.');

						return redirect()->to(base_url());
					}
				}

				$query2 = $this->StoreModel->getInfo(array('id' => $param['id_store']));

				session()->set('username', $query->getRow()->username);
				session()->set('name', $query->getRow()->name);
				session()->set('id_user', $query->getRow()->id_user);
				session()->set('level', $level);
				session()->set('id_store', $param['id_store']);
				session()->set('storeName', $query2->getRow()->name);

				if ($level == 'kasir') {
					return redirect()->to(base_url('transaction_sales'));
				} else {
					return redirect()->to(base_url('dashboard'));
				}
			} else {
				session()->setflashdata('error', 'Username atau password salah');

				return redirect()->to(base_url());
			}
		}
	}

	public function logout()
	{
		session()->destroy();
		return redirect()->to(base_url());
	}
}
