<?php

namespace App\Controllers;

use App\Models\TransactionStockinModel;
use App\Models\ProductItemModel;
use App\Models\SupplierModel;
use App\Models\ConfigTypeModel;
use App\Models\ConfigDetailModel;
use App\Models\StoreModel;
use App\Models\SalesModel;
use App\Models\SalesDetailModel;
use App\Models\UserModel;
use PrintStruk;
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
use Mike42\Escpos\CapabilityProfiles\StarCapabilityProfile;
use Mike42\Escpos\EscposImage;

class Transaction extends BaseController
{
	protected $TransactionStockinModel;
	protected $ProductItemModel;
	protected $SupplierModel;
	protected $ConfigTypeModel;
	protected $ConfigDetailModel;
	protected $StoreModel;
	protected $SalesModel;
	protected $SalesDetailModel;
	protected $UserModel;

	public function __construct()
	{
		$this->TransactionStockinModel = new TransactionStockinModel();
		$this->ProductItemModel = new ProductItemModel();
		$this->SupplierModel = new SupplierModel();
		$this->ConfigTypeModel = new ConfigTypeModel();
		$this->ConfigDetailModel = new ConfigDetailModel();
		$this->StoreModel = new StoreModel();
		$this->SalesModel = new SalesModel();
		$this->SalesDetailModel = new SalesDetailModel();
		$this->UserModel = new UserModel();
	}

	public function sales()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$query = $this->ConfigTypeModel->getInfo(array('name' => 'pembayaran'));
		
		if (count($query->getResult()) > 0) {
			$query2 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query->getRow()->id_config_type));

			if (count($query2->getResult()) > 0) {
				$data = [
					'pembayaran' => $query2->getresult()
				];

				$data['pageTitle'] = 'Transaksi - Penjualan';

				// receipt number
				$query4 = $this->ConfigTypeModel->getInfo(array('name' => 'auto receipt'));
				$query5 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query4->getRow()->id_config_type));
				$query3 = $this->StoreModel->getInfo(array('id' => session()->get('id_store')));

				$numbering = $query5->getrow()->name;

				// reset receipt number
				$explode = explode(" ",$query5->getrow()->updated_date);
				if ($explode[0] != date("Y-m-d")) {
					//update nomernya jadi 1
					$query7 = $this->ConfigDetailModel->updateData(array('name' => 1),$query5->getrow()->id_config_detail);
					$numbering = 1;
				}

				$data['receiptNo'] = $query3->getRow()->kode.".".date('Ymd').".".$query5->getrow()->name;

				return view('transaction/transaction_sales', $data);
			}
		}
	}

	public function stockin()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Transaksi - Stok Masuk';

		return view('transaction/transaction_stockin', $data);
	}

	public function stockin_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->TransactionStockinModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_transaction_stockin . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_transaction_stockin . '-edit" href="transaction_stockin_edit?id=' . $row->id_transaction_stockin . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
                <a title="Delete" id="' . $row->id_transaction_stockin . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_transaction_stockin . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			$query2 = $this->ProductItemModel->getInfo(array('id' => $row->id_product_item));
			$query3 = $this->SupplierModel->getInfo(array('id' => $row->id_supplier));

			if (session()->get('level') == 'admin') {
				$entry = [$i,$row->invoice,ucwords($query3->getRow()->name),ucwords($query2->getRow()->name),$row->quantity,$row->datein,number_format($row->price,0,",","."),$action];
			} else {
				$entry = [$i,$row->invoice,ucwords($query3->getRow()->name),ucwords($query2->getRow()->name),$row->quantity,$action];
			}
			
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function stockout()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Transaksi - Stok Keluar';

		return view('transaction/transaction_stockout', $data);
	}

	public function stockin_add()
	{
		$data['pageTitle'] = 'Stok Masuk - Tambah';

		//kasih no invoice otomatis
		$query4 = $this->ConfigTypeModel->getInfo(array('name' => 'auto invoice'));
		$query5 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query4->getRow()->id_config_type));
		$number = sprintf('%03d', $query5->getrow()->name);
		$data['invoice_no'] = 'HMH-'.date('mY').'-'.$number;

		if ($this->request->getMethod() === 'post' && $this->validate(
			[
				'id_supplier' => 'required',
				'invoice' => 'required'
			]
		)) {
			
			$param['id_supplier'] = $this->request->getVar('id_supplier');
			$param['invoice'] = $this->request->getVar('invoice');
			$param['datein'] = $this->request->getVar('datein');
			
			for ($i=1;$i<=5;$i++) {
				if ($this->request->getVar('id_product_item'.$i) !== "") {
					$param['id_product_item'] = $this->request->getVar('id_product_item'.$i);
					$param['quantity'] = $this->request->getVar('quantity'.$i);
					$param['price'] = $this->request->getVar('price'.$i);
					$query = $this->TransactionStockinModel->insertData($param);

					$param2['stock'] = $this->request->getVar('quantity'.$i);
					$query2 = $this->ProductItemModel->updateData($param2,$param['id_product_item']);
				}
			}

			$update_number = $query5->getrow()->name + 1;
			$query6 = $this->ConfigDetailModel->updateData(array('name' => $update_number), $query5->getrow()->id_config_detail);
			
			session()->setFlashdata('success', 'Data berhasil ditambahkan');

			return redirect()->route('transaction_stockin');
		} else {
			$data['validation'] = $this->validator;
		}

		echo view('transaction/transaction_stockin_add', $data);
	}

	public function transaction_cart()
	{
		if ($this->request->getVar('barcode') !== null) {
			$barcode = $this->request->getVar('barcode');

			$query = $this->ProductItemModel->getInfo(array('barcode' => $barcode));
			
			if (count($query->getResult()) > 0) {
				$product_item[] = [
					'id_product_item' => $query->getRow()->id_product_item,
					'name' => $query->getRow()->name,
					'price' => $query->getRow()->price,
					'qty' => 1
				];

				if (session()->has('cart')) {
					session()->push('cart', $product_item);
				} else {
					session()->set('cart', $product_item);
				}
				
			}

			return redirect()->route('transaction_sales');
		}
	}

	public function transaction_cart_update()
	{
		$qty = $this->request->getVar('qty');

		foreach (session()->get('cart') as $key => $value) {
			$_SESSION['cart'][$key]['qty'] = $qty[$key];
		}

		return redirect()->route('transaction_sales');
	}

	public function transaction_cart_reset()
	{
		session()->remove('cart');
		session()->remove('changes');
		session()->remove('cash');

		return redirect()->route('transaction_sales');
	}

	public function transaction_cart_delete()
	{
		$id = $this->request->getVar('id');
		$cart = session()->get('cart');

		$k = array_filter($cart, function ($var) use ($id){
			return ($var['id_product_item'] == $id);
		});

		foreach ($k as $key => $value) {
			unset($_SESSION['cart'][$key]);
		}

		session()->cart = array_values(session()->cart);

		return redirect()->route('transaction_sales');
	}

	public function transaction_cart_count()
	{
		$cash = $this->request->getVar('cash');
		$subtotal = $this->request->getVar('subtotal');
		$changes = $cash - $subtotal;

		session()->set('changes', $changes);
		session()->set('cash', $cash);

		return redirect()->route('transaction_sales');
	}

	public function transaction_process()
	{
		$param['id_user'] = session()->get('id_user');
		$param['date_sales'] = date('Y-m-d');
		$param['receipt_no'] = $this->request->getVar('receiptNo');
		$param['total'] = $this->request->getVar('total');
		$param['id_config_detail'] = $this->request->getVar('payment_type2');
		$param['payment'] = session()->get('cash');
		$param['payment_change'] = session()->get('changes');
		$query = $this->SalesModel->insertData($param);

		foreach (session()->get('cart') as $row) {
			$param2 = array();
			$param2['id_sales'] = $query;
			$param2['id_product_item'] = $row['id_product_item'];
			$param2['price'] = $row['price'];
			$param2['quantity'] = $row['qty'];
			$param2['total'] = $row['price'] * $row['qty'];
			$query2 = $this->SalesDetailModel->insertData($param2);
		}

		$query4 = $this->ConfigTypeModel->getInfo(array('name' => 'auto receipt'));
		$query5 = $this->ConfigDetailModel->getInfo(array('id_config_type' => $query4->getRow()->id_config_type));
		$update_receipt = $query5->getRow()->name + 1;
		$query3 = $this->ConfigDetailModel->updateData(array('name' => $update_receipt),$query5->getRow()->id_config_detail);

		session()->remove('cart');
		session()->remove('changes');
		session()->remove('cash');
		session()->remove('id_sales');
		session()->set('id_sales', $query);

		return redirect()->route('transaction_print');
	}

	public function transaction_print()
	{
		if (session()->get('id_sales') == '' && $this->request->getVar('id_sales') == '') {
			return redirect()->route('transaction_sales');
		}

		if (session()->get('id_sales') != '') {
			$id = session()->get('id_sales');
		} else {
			$id = $this->request->getVar('id_sales');
		}
		
		$query = $this->SalesModel->getInfo(array('id' => $id));
		$query2 = $this->UserModel->getInfo(array('id' => $query->getRow('id_user')));
		$query3 = $this->SalesDetailModel->getInfo(array('id_sales' => $id));
		$query5 = $this->ConfigDetailModel->getInfo(array('id' => $query->getRow()->id_config_detail));
		
		//ini untuk lokal printer menggunakan USB
		$connector = new WindowsPrintConnector("Printer_Struk");
		$printer = new Printer($connector);
		$img = EscposImage::load("public/img/Homah-Logo-2-bw.png",false);

		// membuat fungsi untuk membuat 1 baris tabel, agar dapat dipanggil berkali-kali dgn mudah
        function buatBaris4Kolom($kolom1, $kolom2, $kolom3, $kolom4) {
            // Mengatur lebar setiap kolom (dalam satuan karakter)
            $lebar_kolom_1 = 22;
            $lebar_kolom_2 = 3;
            $lebar_kolom_3 = 7;
            $lebar_kolom_4 = 7;

            // Melakukan wordwrap(), jadi jika karakter teks melebihi lebar kolom, ditambahkan \n 
            $kolom1 = wordwrap($kolom1, $lebar_kolom_1, "\n", true);
            $kolom2 = wordwrap($kolom2, $lebar_kolom_2, "\n", true);
            $kolom3 = wordwrap($kolom3, $lebar_kolom_3, "\n", true);
            $kolom4 = wordwrap($kolom4, $lebar_kolom_4, "\n", true);
 
            // Merubah hasil wordwrap menjadi array, kolom yang memiliki 2 index array berarti memiliki 2 baris (kena wordwrap)
            $kolom1Array = explode("\n", $kolom1);
            $kolom2Array = explode("\n", $kolom2);
            $kolom3Array = explode("\n", $kolom3);
            $kolom4Array = explode("\n", $kolom4);
 
            // Mengambil jumlah baris terbanyak dari kolom-kolom untuk dijadikan titik akhir perulangan
            $jmlBarisTerbanyak = max(count($kolom1Array), count($kolom2Array), count($kolom3Array), count($kolom4Array));
 
            // Mendeklarasikan variabel untuk menampung kolom yang sudah di edit
            $hasilBaris = array();
 
            // Melakukan perulangan setiap baris (yang dibentuk wordwrap), untuk menggabungkan setiap kolom menjadi 1 baris 
            for ($i = 0; $i < $jmlBarisTerbanyak; $i++) {
 
                // memberikan spasi di setiap cell berdasarkan lebar kolom yang ditentukan, 
                $hasilKolom1 = str_pad((isset($kolom1Array[$i]) ? $kolom1Array[$i] : ""), $lebar_kolom_1, " ");
                $hasilKolom2 = str_pad((isset($kolom2Array[$i]) ? $kolom2Array[$i] : ""), $lebar_kolom_2, " ");
 
                // memberikan rata kanan pada kolom 3 dan 4 karena akan kita gunakan untuk harga dan total harga
                $hasilKolom3 = str_pad((isset($kolom3Array[$i]) ? $kolom3Array[$i] : ""), $lebar_kolom_3, " ", STR_PAD_LEFT);
                $hasilKolom4 = str_pad((isset($kolom4Array[$i]) ? $kolom4Array[$i] : ""), $lebar_kolom_4, " ", STR_PAD_LEFT);
 
                // Menggabungkan kolom tersebut menjadi 1 baris dan ditampung ke variabel hasil (ada 1 spasi disetiap kolom)
                $hasilBaris[] = $hasilKolom1 . " " . $hasilKolom2 . " " . $hasilKolom3 . " " . $hasilKolom4;
            }
 
            // Hasil yang berupa array, disatukan kembali menjadi string dan tambahkan \n disetiap barisnya.
            return implode("\n", $hasilBaris) . "\n";
        }

		try {
			// membuat judul
			$printer->initialize();
			$printer->setFont(Printer::FONT_A);
			$printer->setJustification(Printer::JUSTIFY_CENTER);
			$printer->bitImage($img);
			$printer->text("Ruko Apartemen Serpong\n");
			$printer->text("Green View RK03A\n");
			$printer->text("0878-7710-0071\n");
			$printer->text("________________________________\n");

			//Data transaksi
			$printer->initialize();
			$printer->setFont(Printer::FONT_B);
			$printer->setJustification(Printer::JUSTIFY_LEFT);
			$printer->text("Receipt No: ".$query->getRow()->receipt_no."\n");
			$printer->text("Kasir: ".$query2->getRow()->name." | ".$query->getRow()->created_date."\n");

			//Membuat tabel
			$printer->initialize();
			$printer->setFont(Printer::FONT_B);
			$printer->setJustification(Printer::JUSTIFY_LEFT);
			$printer->text("__________________________________________\n");

			foreach ($query3->getResult() as $row) {
				$query4 = $this->ProductItemModel->getInfo(array('id' => $row->id_product_item));
				
				$printer->text(buatBaris4Kolom($query4->getRow()->name, $row->quantity, number_format($row->price,0,',','.'), number_format($row->total,0,',','.')));
			}

			$printer->text("__________________________________________\n");

			//Total transaksi
			$printer->initialize();
			$printer->setFont(Printer::FONT_B);
			$printer->setJustification(Printer::JUSTIFY_RIGHT);
			//$printer->text(buatBaris4Kolom('', '', "Total", number_format($query->getRow()->total),0,',','.'));
			$printer->text("Total: ".number_format($query->getRow()->total,0,',','.')."\n");
			$printer->text($query5->getRow()->name.": ".number_format($query->getRow('payment'),0,',','.')."\n");
			$printer->text("Kembalian: ".number_format($query->getRow('payment_change'),0,',','.')."\n");

			//Pesan penutup
			$printer->initialize();
			$printer->setFont(Printer::FONT_B);
			$printer->setJustification(Printer::JUSTIFY_CENTER);
			$printer->text("==========================================\n");
			$printer->text("Terima kasih\n");
			$printer->text("Barang yang sudah dibeli\n");
			$printer->text("tidak dapat dikembalikan\n\n");
			$printer->text("homah.indonesia@gmail.com");

			// mencetak 3 baris kosong, agar kertas terangkat ke atas
			$printer->feed(3);
		
			/* Close printer */
			$printer->close();

			session()->remove('id_sales');
			return redirect()->route('transaction_sales');
		} catch(Exception $e) {
			echo "TIDAK TERKONEKSI DENGAN PRINTER: " . $e -> getMessage() . "\n";
		}
	}
}
