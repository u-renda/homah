<?php

namespace App\Controllers;

use App\Models\SalesModel;
use App\Models\UserModel;
use App\Models\ConfigDetailModel;
use App\Models\SalesDetailModel;
use App\Models\ProductItemModel;

class Report extends BaseController
{
	protected $SalesModel;
	protected $UserModel;
	protected $ConfigDetailModel;
	protected $SalesDetailModel;
	protected $ProductItemModel;

	public function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->UserModel = new UserModel();
		$this->ConfigDetailModel = new ConfigDetailModel();
		$this->SalesDetailModel = new SalesDetailModel();
		$this->ProductItemModel = new ProductItemModel();
	}

	public function sales()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Laporan - Penjualan';

		return view('report/report_sales', $data);
	}
	
	public function report_sales_detail()
	{
		if ($this->request->getVar('id') != ''){
			$data['id'] = $this->request->getVar('id');

			$query =  $this->SalesModel->getInfo(array('id' => $data['id']));

			$data['pageTitle'] = 'Laporan - Detail Penjualan - '.$query->getRow()->receipt_no;

			return view('report/report_sales_detail',$data);
		} else {
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}
	}

	public function report_sales_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$i = 1;
		$query = $this->SalesModel->getAll();

		foreach ($query->getResult() as $row) {
			$action = '<a title="Detail" id="' . $row->id_sales . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_sales . '-edit" href="report_sales_detail?id=' . $row->id_sales . '"><i class="fa fa-pencil"></i> Detail</a>&nbsp;
				<a class="mb-xs mt-xs mr-xs btn btn-sm btn-success" href="transaction_print?id_sales='.$row->id_sales.'"><i class="fa fa-send"></i> Print </a>';

			//cek kasir
			$query2 = $this->UserModel->getInfo(array('id' => $row->id_user));

			//cek pembayaran
			$query3 = $this->ConfigDetailModel->getInfo(array('id' => $row->id_config_detail));

			$entry = [$i,$row->date_sales,$query2->getRow()->name,$row->receipt_no,number_format($row->total,0,",","."),$query3->getRow()->name,$action];
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function report_sales_detail_get()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$id_sales = $this->request->getVar('id');
		$i = 1;
		$query = $this->SalesDetailModel->getInfo(array('id_sales' => $id_sales));

		foreach ($query->getResult() as $row) {
			$action = '<a title="Ubah" id="' . $row->id_sales_detail . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-primary text-white edit ' . $row->id_sales_detail . '-edit" href="sales_detail_edit?id=' . $row->id_sales_detail . '"><i class="fa fa-pencil"></i> Ubah</a>&nbsp;
                        <a title="Delete" id="' . $row->id_sales_detail . '" class="mb-xs mt-xs mr-xs btn btn-sm btn-danger text-white delete ' . $row->id_sales_detail . '-delete" href="#"><i class="fa fa-times"></i> Hapus</a>';

			//cek nama barang
			$query2 = $this->ProductItemModel->getInfo(array('id' => $row->id_product_item));

			$entry = [$i,$query2->getRow()->name,number_format($row->price,0,",","."),$row->quantity,number_format($row->total,0,",","."),$action];
			$jsonData['data'][] = $entry;
			$i++;
		}

		echo json_encode($jsonData);
	}

	public function stock()
	{
		//check session
		if (empty(session()->get('username'))) {
			return redirect()->to(base_url());
		}

		$data['pageTitle'] = 'Laporan - Stok';

		return view('report/report_stock', $data);
	}
}
