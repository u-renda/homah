<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Login::index');
$routes->get('/dashboard', 'Home');
$routes->get('/logout', 'Login::logout');

$routes->get('/product_category', 'Product::category');
$routes->get('/product_brand', 'Product::brand');
$routes->get('/product_item', 'Product::item');
$routes->get('/upload_new_item', 'Product::upload_new_item');
$routes->get('/print_barcode', 'Product::print_barcode');
$routes->get('/transaction_sales', 'Transaction::sales');
$routes->get('/transaction_stockin', 'Transaction::stockin');
$routes->get('/transaction_stockout', 'Transaction::stockout');
$routes->get('/report_sales', 'Report::sales');
$routes->get('/report_sales_detail', 'Report::report_sales_detail');
$routes->get('/report_stock', 'Report::stock');
$routes->get('/my_profile', 'User::my_profile');
$routes->get('/supplier', 'Supplier::index');
$routes->get('/user', 'User::index');
$routes->get('/setting', 'Setting::config_type');
$routes->get('/config_detail', 'Setting::config_detail');
$routes->get('/transaction_cart_reset', 'Transaction::transaction_cart_reset');
$routes->get('/transaction_cart_delete', 'Transaction::transaction_cart_delete');
$routes->get('/transaction_print', 'Transaction::transaction_print');

$routes->post('/product_category_delete', 'Product::category_delete');
$routes->post('/product_item_delete', 'Product::item_delete');
$routes->post('/product_brand_delete', 'Product::brand_delete');
$routes->post('/supplier_delete', 'Supplier::supplier_delete');
$routes->post('/transaction_cart', 'Transaction::transaction_cart');
$routes->post('/transaction_cart_update', 'Transaction::transaction_cart_update');
$routes->post('/transaction_cart_count', 'Transaction::transaction_cart_count');
$routes->post('/transaction_process', 'Transaction::transaction_process');

$routes->match(['get', 'post'], '/product_category_add', 'Product::category_add');
$routes->match(['get', 'post'], '/product_category_edit', 'Product::category_edit');
$routes->match(['get', 'post'], '/product_category_get', 'Product::category_get');
$routes->match(['get', 'post'], '/product_item_get', 'Product::item_get');
$routes->match(['get', 'post'], '/product_item_add', 'Product::item_add');
$routes->match(['get', 'post'], '/product_item_edit', 'Product::item_edit');
$routes->match(['get', 'post'], '/product_brand_get', 'Product::brand_get');
$routes->match(['get', 'post'], '/product_brand_add', 'Product::brand_add');
$routes->match(['get', 'post'], '/product_brand_edit', 'Product::brand_edit');
$routes->match(['get', 'post'], '/transaction_stockin_get', 'Transaction::stockin_get');
$routes->match(['get', 'post'], '/transaction_stockin_add', 'Transaction::stockin_add');
$routes->match(['get', 'post'], '/transaction_stockin_edit', 'Transaction::stockin_edit');
$routes->match(['get', 'post'], '/supplier_get', 'Supplier::supplier_get');
$routes->match(['get', 'post'], '/supplier_add', 'Supplier::supplier_add');
$routes->match(['get', 'post'], '/supplier_edit', 'Supplier::supplier_edit');
$routes->match(['get', 'post'], '/user_get', 'User::user_get');
$routes->match(['get', 'post'], '/user_add', 'User::user_add');
$routes->match(['get', 'post'], '/user_edit', 'User::user_edit');
$routes->match(['get', 'post'], '/config_type_get', 'Setting::config_type_get');
$routes->match(['get', 'post'], '/config_type_add', 'Setting::config_type_add');
$routes->match(['get', 'post'], '/config_type_edit', 'Setting::config_type_edit');
$routes->match(['get', 'post'], '/config_detail_get', 'Setting::config_detail_get');
$routes->match(['get', 'post'], '/config_detail_add', 'Setting::config_detail_add');
$routes->match(['get', 'post'], '/config_detail_edit', 'Setting::config_detail_edit');
$routes->match(['get', 'post'], '/report_sales_get', 'Report::report_sales_get');
$routes->match(['get', 'post'], '/report_sales_detail_get', 'Report::report_sales_detail_get');

$routes->match(['get', 'post'], '/search_supplier', 'Supplier::search_supplier');
$routes->match(['get', 'post'], '/search_product_item', 'Product::search_product_item');
$routes->match(['get', 'post'], '/prosesExcel', 'Product::prosesExcel');

/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
